// CS145 Hybrid
// Programmers: 
// 12/05/2022
//Assignment 2: Phone Book
//Linkedlist is to clear to explean, I can explean it if necessary
//for extra cridet I wrote this likedlist myself 
package phone;


public class CLinkedList<ObjectType> {
    private CNode head = null;
    private CNode tail = null;
    public int GetSize(){
        int size = 0;
        CNode<ObjectType> h = GetHead();
        while (h != null){            
            size++;
            h = h.GetNext();
        }
        return size;
    }
    public CNode GetHead(){ return head; }
    public CNode GetTail(){ return tail; }
    private void SetHead(CNode e){ head = e; }
    private void SetTail(CNode e){ tail = e; }
    public void Add(ObjectType e){
        if(GetSize() == 0){
            CNode tmp = new CNode();
            tmp.SetData(e);
            SetHead(tmp);
            SetTail(tmp);
        }else{
            CNode<ObjectType> tmp = new CNode<>();
            tmp.SetData(e);
            tail.SetNext(tmp);
            SetTail(tmp);
        }
    }
    public void AddFirst(ObjectType e){
        CNode<ObjectType> tmp = new CNode<>();
        tmp.SetData(e);
        tmp.SetNext(head);
        SetHead(tmp);
    }
    public void AddLast(ObjectType e){ Add(e); }
    public void AddAfter(ObjectType eNew, ObjectType eOld){
        CNode<ObjectType> f = Find(eOld);
        if(f != null){
            CNode<ObjectType> tmp = new CNode<>();
            tmp.SetData(eNew);
            tmp.SetNext(f.GetNext());
            f.SetNext(tmp);
        }
    }
    public void AddBefore(ObjectType eNew, ObjectType eOld){
        CNode<ObjectType> f = Find(eOld);
        if(f != null){
            CNode<ObjectType> tmp = new CNode<>();
            tmp.SetData(eNew);
            tmp.SetNext(f.GetNext());
            f.SetNext(tmp);
        }
    }
    public CNode<ObjectType> Find(ObjectType e){
        CNode<ObjectType> h = GetHead();
        while (h != null){            
            if(h.GetData() == e){
                return h;
            }
            h = h.GetNext();
        }
        return null;
    }
    public ObjectType Get(int e){
        CNode<ObjectType> h = GetHead();
        int current = 0;
        while (h != null){
            if(current == e)
                return h.GetData();
            current++;
            h = h.GetNext();
        }
        return null;
    }
    public void RemoveFirst(){
        if(GetHead() == null) return;
        SetHead(GetHead().GetNext());
    }
    public void RemoveLast(){
        if(head == null) return;
        if(head.GetNext() == null){
            head = null;
            return;
        }
        CNode<ObjectType> h = GetHead();
        while(h.GetNext().GetNext() != null)
            h = h.GetNext();
        h.SetNext(null);
    }
    public void Remove(ObjectType e){
        CNode<ObjectType> h = GetHead();
        while (h.GetNext() != Find(e)){            
            h = h.GetNext();
        }
        h.SetNext(h.GetNext().GetNext());
    }
    public void Remove(CNode e){
        CNode<ObjectType> h = GetHead();
        while (h.GetNext() != e){            
            h = h.GetNext();
        }
        h.SetNext(h.GetNext().GetNext());
    }
    public void Remove(int e){
        if(e < 1){
            RemoveFirst();
        }else{
            Remove(Find(Get(e)));
        }
        
    }
    public void Clear(){
        while (GetSize() > 0) {            
            RemoveLast();
        }
    }
    @Override
    public String toString(){
        String result = "";
        CNode<ObjectType> h = GetHead();
        while (h != null){            
            result += "[" + h.GetData() + "]\t";
            h = h.GetNext();
        }
        return result;
    }
}
class CNode<ObjectType> {
    ObjectType data;
    CNode next;
    protected void SetNext(CNode e){ next = e; }
    protected CNode GetNext(){ return next; }
    protected ObjectType GetData(){ return data; }
    public void SetData(ObjectType e){
        data = e;
    }
    @Override
    public String toString(){
        return data.toString();
    }
}