// CS145 Hybrid
// Programmers: 
// 12/05/2022
//Assignment 2: Phone Book
package phone;

public class Profile {
    //Storge contact data
    private String firstName = "";
    private String middleName = "";
    private String lastName = "";
    private String cellNumber = "";
    private String workNumber = "";
    private String homeEmail = "";
    private String workEmail = "";
    private String street = "";
    private String state = "";
    private String city = "";
    private String zIPCode = "";
    private String country = "";
    public Profile() {//To create a profile with empty data
        
    }
    public Profile(String fN) {//To create a profile with the first name
        SetFristName(fN);
    }
    public void SetFristName(String e){ firstName = e; }
    public void SetMiddleName(String e){ middleName = e; }
    public void SetLastName(String e){ lastName = e; }
    public void SetStreet(String e){ street = e; }
    public void SetCity(String e){ city = e; }
    public void SetState(String e){ state = e; }
    public void SetZIPCode(String e){ zIPCode = e; }
    public void SetCountry(String e){ country = e; }
    public void SetCellNumber(String e){ cellNumber = e; }
    public void SetWorkNumber(String e){ workNumber = e; }
    public void SetHomeEmail(String e){ homeEmail = e; }
    public void SetWorkEmail(String e){ workEmail = e; }
    public String GetFristName(){ return firstName; }
    public String GetMiddleName(){ return middleName; }
    public String GetLastName(){ return lastName; }
    public String GetFullName(){ return firstName + " " + middleName + " " + lastName; }
    public String GetCellNumber(){ return cellNumber; }
    public String GetWorkNumber(){ return workNumber; }
    public String GetHomeEmail(){ return homeEmail; }
    public String GetWorkEmail(){ return workEmail; }
    public String GetStreet(){ return street; }
    public String GetCity(){ return city; }
    public String GetState(){ return state; }
    public String GetZIPCode(){ return zIPCode; }
    public String GetCountry(){ return country; }
    public String ExtractData(){//To extract the contact as vcf contact format file
        String result = "BEGIN:VCARD\nVERSION:2.1";
        result += "\nN:" + GetLastName() + ";" + GetFristName() + ";" + GetMiddleName() + ";;";
        result += "\nFN:" + GetFristName() + " " + GetMiddleName() + " " + GetLastName();
        if(GetCellNumber() != "")
            result += "\nTEL;HOME:" + GetCellNumber();
        if(GetWorkNumber()!= "")
            result += "\nTEL;WORK:" + GetWorkNumber();
        if(GetHomeEmail()!= "")
            result += "\nEMAIL;HOME:" + GetHomeEmail();
        if(GetWorkEmail()!= "")
            result += "\nEMAIL;WORK:" + GetWorkEmail();
        if(GetStreet() != "" || GetCity() != "" || GetState() != "" || GetZIPCode() != "" || GetCountry() != "")
            result += "\nADR;HOME:;;" + GetStreet() + ";" + GetCity() + ";" + GetState() + ";" + GetZIPCode() + ";" + GetCountry();
        result += "\nEND:VCARD";
        return result;
    }
    @Override
    public String toString(){
        return GetFristName() + " " + GetMiddleName() + " " + GetLastName() + "\n" + GetCellNumber() + "\n" + GetHomeEmail() + "\n" + GetStreet()+ "\n" + GetCity() + ", " + GetState();
    }
}