// CS145 Hybrid
// Programmers:
// 12/05/2022
//Assignment 2: Phone Book
//I did a lot for extra cridet
//I would like to explean everything in zoom or class
//For extra credit I put more fetcher for addidng info to the content
//For extra credit Save and loud data 
//For extra credit Saving the data Virtual Contact File format, and use it on your phone or windows people app
package phone;

import java.io.IOException;
import java.util.Scanner;
public class Tester {
    public static void main(String[] args) throws IOException{
        Manger phoneBookSys = new Manger();//Declare object of manager
        phoneBookSys.LoadData();//Load data of contacts
        System.out.println("Welcome to JAVA Phone Book\n");
        for(boolean isRunning = true; isRunning;){//This loop is making the program running until the user shut it down
            System.out.print("1- Browse & edit contacts\n2- Create contact\n3- Search\n4- About & help\n5- Exit\nEnter your order>>\t");//Menu options
            switch(new Scanner(System.in).nextInt()){//Switch for moving between options
                case 1:
                    for(boolean inside = true; inside; ){//Running browse and edit contacts until user shut it down
                        System.out.println("\tTo turn back enter number zero.");
                        for(int i = 0; i < phoneBookSys.GetProfileSize(); i++){//this loop job is sorting all contacts in the program
                            System.out.println("\t" + (i + 1) + "- " + phoneBookSys.GetProfile(i).GetFullName());
                        }
                        System.out.print("\n\tEnter your order>>\t");
                        int order = new Scanner(System.in).nextInt();//The number of contact we choose
                        if(order - 1 >= 0 && order - 1 < phoneBookSys.GetProfileSize()){//This (if condition) job is to show contact options
                            System.out.print("\n\tProfile name:\t" + phoneBookSys.GetProfile(order - 1).GetFullName() + "\n\tTo turn back do not enter one of the options.\n\t1- Show profile data\n\t2- Edit profile\n\t3- Delete contact\n\tEnter your order>>\t");
                            switch(new Scanner(System.in).nextInt()){//Switch for moving between options
                                case 1:
                                    System.out.println("\n" + phoneBookSys.ShowProfile(order - 1) + "\n");//This line for showing contact data
                                    break;
                                case 2://This option to give the user edit contact data options
                                    System.out.print("\t\tEdit menu\n\t\tTo turn back do not enter one of the options.\n\n\t\t1-  Set first name\n\t\t2-  Set second name\n\t\t3-  Set last name\n\t\t4-  Set cell phone number\n\t\t5-  Set work phone number\n\t\t6-  Set main email\n\t\t7-  Set work email\n\t\t8-  Set street address\n\t\t9-  Set state address\n\t\t10- Set city address\n\t\t11- Set ZIP Code address\n\t\t12- Set country address\n\t\tEnter your order>>\t");
                                    switch(new Scanner(System.in).nextInt()){//Switch for moving between options
                                        case 1:
                                            System.out.print("\t\t\tEnter the first name:\t");
                                            phoneBookSys.GetProfile(order - 1).SetFristName(new Scanner(System.in).next());//Edit or add first name
                                            break;
                                        case 2:
                                            System.out.print("\t\t\tEnter the second name:\t");
                                            phoneBookSys.GetProfile(order - 1).SetMiddleName(new Scanner(System.in).next());//Edit or add second name
                                            break;
                                        case 3:
                                            System.out.print("\t\t\tEnter the last name:\t");
                                            phoneBookSys.GetProfile(order - 1).SetLastName(new Scanner(System.in).next());//Edit or add last name
                                            break;
                                        case 4:
                                            System.out.print("\t\t\tEnter cell phone number:\t");
                                            phoneBookSys.GetProfile(order - 1).SetCellNumber(new Scanner(System.in).next());//Edit or add main phone number
                                            break;
                                        case 5:
                                            System.out.print("\t\t\tEnter work phone number:\t");
                                            phoneBookSys.GetProfile(order - 1).SetWorkNumber(new Scanner(System.in).next());//Edit or add work phone number
                                            break;
                                        case 6:
                                            System.out.print("\t\t\tEnter main email:\t");
                                            phoneBookSys.GetProfile(order - 1).SetHomeEmail(new Scanner(System.in).next());//Edit or add main email
                                            break;
                                        case 7:
                                            System.out.print("\t\t\tEnter work email:\t");
                                            phoneBookSys.GetProfile(order - 1).SetWorkEmail(new Scanner(System.in).next());//Edit or add work email
                                            break;
                                        case 8:
                                            System.out.print("\t\t\tEnter street address:\t");
                                            phoneBookSys.GetProfile(order - 1).SetStreet(new Scanner(System.in).next());//Edit or add street 
                                            break;
                                        case 9:
                                            System.out.print("\t\t\tEnter state:\t");
                                            phoneBookSys.GetProfile(order - 1).SetState(new Scanner(System.in).next());//Edit or add state
                                            break;
                                        case 10:
                                            System.out.print("\t\t\tEnter city:\t");
                                            phoneBookSys.GetProfile(order - 1).SetCity(new Scanner(System.in).next());//Edit or add city
                                            break;
                                        case 11:
                                            System.out.print("\t\t\tEnter ZIP code:\t");
                                            phoneBookSys.GetProfile(order - 1).SetZIPCode(new Scanner(System.in).next());//Edit or add ZIP code
                                            break;
                                        case 12:
                                            System.out.print("\t\t\tEnter country:\t");
                                            phoneBookSys.GetProfile(order - 1).SetCountry(new Scanner(System.in).next());//Edit or add country
                                            break;
                                    }
                                    phoneBookSys.SaveData(order - 1);//Save contect data
                                    break;
                                case 3:
                                    phoneBookSys.DeleteContact(order - 1);//Delete contact data
                                    break;
                            }
                        }else if(order == 0){//This (if condition) job is to go back to the main menu
                            inside = false;
                        }else{
                        
                        }
                    }
                    break;
                case 2://Creating new contact
                    System.out.print("\tEnter the frist name:\t");
                    String name = new Scanner(System.in).next();//To store the first name to the cache variable to let other data store in the same contact
                    phoneBookSys.AddProfile(name);//To add profile of the contacts, and set the first name
                    System.out.print("\tEnter the middle name:\t");
                    phoneBookSys.GetProfile(phoneBookSys.GetProfileAddress(name)).SetMiddleName(new Scanner(System.in).next());//Set the second name
                    System.out.print("\tEnter the last name:\t");
                    phoneBookSys.GetProfile(phoneBookSys.GetProfileAddress(name)).SetLastName(new Scanner(System.in).next());//Set the last name
                    System.out.print("\tEnter phone number:\t");
                    phoneBookSys.GetProfile(phoneBookSys.GetProfileAddress(name)).SetCellNumber(new Scanner(System.in).next());//Set the main phone number
                    System.out.print("\tEnter Email:\t\t");
                    phoneBookSys.GetProfile(phoneBookSys.GetProfileAddress(name)).SetHomeEmail(new Scanner(System.in).next());//Set the main email
                    phoneBookSys.SaveData(phoneBookSys.GetProfileAddress(name));//Save contect data
                    break;
                case 3:
                    System.out.print("Enter first name:\t");
                    System.out.println("\n" + phoneBookSys.ShowProfile(phoneBookSys.GetProfileAddress(new Scanner(System.in).next())) + "\n");//This line for showing contact data
                    
                    break;
                case 4:
                    System.out.println("● JAVA Phone Book.\n● Author: Meshal Aldhawyan\n● For every change done the application will reload data again to be syncing.\n");
                    break;
                case 5:
                    isRunning = false;//To break the main loop, to exit
                    System.out.println("I hope you got a great try with my JAVA application :)");
                    break;
                default:
                    System.out.println("[Debug(Invalid input)]\n\t\tSorry, but you need to insert one of the options above.\n");
            }
            phoneBookSys.LoadData();//Load data after any change
        }//End of loop
    }//End of main method
}//End of class