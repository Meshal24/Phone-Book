// CS145 Hybrid
// Programmers: 
// 12/05/2022
//Assignment 2: Phone Book
package phone;

import java.io.*;
public class Manger{
    private CLinkedList<Profile> profile = new CLinkedList<>();//Declare profile as linkedlist 
    public Profile GetProfile(int e){ return profile.Get(e); }//To get a profile by number 
    public int GetProfileSize(){ return profile.GetSize(); }//To get profile linkedlist size
    public int GetProfileAddress(String e){//To get a proflie address of linkedlist by first name of contact
        for(int i = 0; i < profile.GetSize(); i++){//This loop is scrolling in profiles
            if(e.equals(profile.Get(i).GetFristName())){//This (if condition) job is to find the what we looking at
                return i;//Give the number of the profile we need
            }
        }
        System.err.println("No matching found!");
        return -1;
    }
    public void AddProfile(String firstName){//Add new profile, and set first name in the same time
        profile.AddLast(new Profile(firstName));
    }
    public void AddProfile(){//Add new profile
        profile.AddLast(new Profile());
    }
    public void DeleteContact(int e) throws IOException{//Deleteing a contect
        new File(System.getProperty("user.home") + "\\Documents\\JavaPhoneBook\\" + profile.Get(e).GetLastName()+ profile.Get(e).GetFristName()+ profile.Get(e).GetMiddleName()+ ".vcf").delete();
        LoadData();
    }
    public String ShowProfile(int e){
        String result = "";
        result += "Full name:\t" + profile.Get(e).GetFullName();//Give us the full name of the contact
        if(profile.Get(e).GetCellNumber()!= "")//To check over the main phone number exist
            result += "\nPhone (Home):\t" + profile.Get(e).GetCellNumber();//Give us the main phone number
        if(profile.Get(e).GetWorkNumber()!= "")//To check over the work number exist
            result += "\nPhone (Work):\t" + profile.Get(e).GetWorkNumber();//Give us the work phone number
        if(profile.Get(e).GetHomeEmail()!= "")//To check over the main email exist
            result += "\nEmail (Home):\t" + profile.Get(e).GetHomeEmail();//Give us the main email
        if(profile.Get(e).GetWorkEmail()!= "")//To check over the work email exist
            result += "\nEmail (Work):\t" + profile.Get(e).GetWorkEmail();//Give us the work email
        if(profile.Get(e).GetStreet()!= "" || profile.Get(e).GetCity()!= "" || profile.Get(e).GetState()!= ""){//To check one of the addresses
            result += "\nAddress:_";
            if(profile.Get(e).GetStreet() != "")//To check over the street exist
                result += "\n\tStreet:\t" + profile.Get(e).GetStreet();//Give us the street name
            if(profile.Get(e).GetCity()!= "")//To check over the city exist
                result += "\n\tCity:\t\t" +  profile.Get(e).GetCity();//Give us the city name
            if(profile.Get(e).GetState()!= "")//To check over the state exist
                result += "\n\tState:\t\t" +  profile.Get(e).GetState();//Give us the state name
            if(profile.Get(e).GetZIPCode()!= "")//To check over the ZIP code exist
                result += "\n\tZIP code:\t" +  profile.Get(e).GetZIPCode();//Give us the ZIP code
            if(profile.Get(e).GetCountry()!= "")//To check over the country exist
                result += "\n\tCountry:\t" +  profile.Get(e).GetCountry();//Give us the country name
        }
        return result;
    }
    public int FindWordLastAddress(String eWord, String eFullText, int times){//Find the address of the word inside text
        int counter = 0;
        int repeted = 0;
        for(int i = 0; i < eFullText.length(); i++){
            if(eWord.charAt(counter) == eFullText.charAt(i)){
                counter++;
            }else{
                counter = 0;
            }
            if(counter >= eWord.length()){
                repeted++;
                counter = 0;
            }
            if(repeted >= times){
                return i;
            }
        }
        return -1;
    }
    public boolean isWordExist(String eWord, String eFullText){//Find if the word inside the text
        int counter = 0;
        if(eFullText != null){
            for(int i = 0; i < eFullText.length(); i++){
                if(eWord.charAt(counter) == eFullText.charAt(i)){
                    counter++;
                }else{
                    counter = 0;
                }
                if(counter >= eWord.length()){
                    return true;
                }
            }
        }
        return false;
    }
    public void LoadData() throws IOException{//Load contacts data
        profile.Clear();//Clear the linkedlist
        FileVerification();//To check the directory and files
        for (File file : new File(System.getProperty("user.home") + "\\Documents\\JavaPhoneBook\\").listFiles()) {//Scrolling for all files
            if (!file.isDirectory()) {
                AddProfile();//Add a new contact
                String cacheMemory = "";
                String cacheData = "";
                BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.home") + "\\Documents\\JavaPhoneBook\\" + file.getName()));//To read the file
                br.readLine();//To skip the line
                br.readLine();//To skip the line
                while (cacheMemory != null) {//To scroll all the lins
                    cacheMemory = br.readLine();//To read the file line
                    if(isWordExist("N:", cacheMemory) && !isWordExist("FN:", cacheMemory)){//Check for the full name
                        for(int i = FindWordLastAddress("N:", cacheMemory, 1) + 1; i < FindWordLastAddress(";", cacheMemory, 1); i++){//To get the last name 
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetLastName(cacheData); cacheData = "";//To store the last name and clear catch data varible
                        for(int i = FindWordLastAddress(";", cacheMemory, 1) + 1; i < FindWordLastAddress(";", cacheMemory, 2); i++){//To get the first name
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetFristName(cacheData); cacheData = "";//To store the firest name and clear catch data varible
                        for(int i = FindWordLastAddress(";", cacheMemory, 2) + 1; i < FindWordLastAddress(";;", cacheMemory, 1) - 1; i++){//To get the second name
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetMiddleName(cacheData); cacheData = "";//To store the last name and clear catch data varible
                    }
                    if(isWordExist("TEL;HOME:", cacheMemory)){//Check for the main phone number
                        for(int i = FindWordLastAddress("TEL;HOME:", cacheMemory, 1) + 1; i < cacheMemory.length(); i++){//To get the main phone number
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetCellNumber(cacheData); cacheData = "";//To store the main phone number and clear catch data varible
                    }
                    if(isWordExist("TEL;WORK:", cacheMemory)){//Check for the work phone number
                        for(int i = FindWordLastAddress("TEL;WORK:", cacheMemory, 1) + 1; i < cacheMemory.length(); i++){//To get the work phone number
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetWorkNumber(cacheData); cacheData = "";//To store the work phone number and clear catch data varible
                    }
                    if(isWordExist("EMAIL;HOME:", cacheMemory)){//Check for the main meail
                        for(int i = FindWordLastAddress("EMAIL;HOME:", cacheMemory, 1) + 1; i < cacheMemory.length(); i++){//To get the main email
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetHomeEmail(cacheData); cacheData = "";//To store the main email and clear catch data varible
                    }
                    if(isWordExist("EMAIL;WORK:", cacheMemory)){//Check for the work email
                        for(int i = FindWordLastAddress("EMAIL;WORK:", cacheMemory, 1) + 1; i < cacheMemory.length(); i++){//To get the work email
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetWorkEmail(cacheData); cacheData = "";//To store the work email and clear catch data varible
                    }
                    if(isWordExist("ADR;HOME:", cacheMemory)){//Check for the address
                        for(int i = FindWordLastAddress(";", cacheMemory, 3) + 1; i < FindWordLastAddress(";", cacheMemory, 4); i++){//To get the street
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetStreet(cacheData); cacheData = "";//To store the street name and clear catch data varible
                        for(int i = FindWordLastAddress(";", cacheMemory, 4) + 1; i < FindWordLastAddress(";", cacheMemory, 5); i++){//To get the city
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetCity(cacheData); cacheData = "";//To store the city name and clear catch data varible
                        for(int i = FindWordLastAddress(";", cacheMemory, 5) + 1; i < FindWordLastAddress(";", cacheMemory, 6); i++){//To get the state
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetState(cacheData); cacheData = "";//To store the state name and clear catch data varible
                        for(int i = FindWordLastAddress(";", cacheMemory, 6) + 1; i < FindWordLastAddress(";", cacheMemory, 7); i++){//To get the ZIP code
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetZIPCode(cacheData); cacheData = "";//To store the ZIP code and clear catch data varible
                        for(int i = FindWordLastAddress(";", cacheMemory, 7) + 1; i < cacheMemory.length(); i++){//To get the country
                            cacheData += cacheMemory.charAt(i);
                        }
                        profile.Get(profile.GetSize() - 1).SetCountry(cacheData); cacheData = "";//To store the country name and clear catch data varible
                    }
                }
                br.close();//To end of the reading
            }
	}
    }
    public void SaveData(int e) throws IOException{//To save the contact
        FileVerification();//To check the directory and files
        BufferedWriter bw = new BufferedWriter(new FileWriter(System.getProperty("user.home") + "\\Documents\\JavaPhoneBook\\" + profile.Get(e).GetLastName()+ profile.Get(e).GetFristName()+ profile.Get(e).GetMiddleName()+ ".vcf"));
        bw.write(profile.Get(e).ExtractData());
        bw.close();
    }
    public void FileVerification() throws IOException{//To check the directory and files
        if(!new File(System.getProperty("user.home") + "\\Documents\\JavaPhoneBook").exists()){ // Check if folder exist
            new File(System.getProperty("user.home") + "\\Documents\\JavaPhoneBook").mkdir(); // Create folder
            System.out.println("System created a new directory.");
        }
    }
}//End of class
